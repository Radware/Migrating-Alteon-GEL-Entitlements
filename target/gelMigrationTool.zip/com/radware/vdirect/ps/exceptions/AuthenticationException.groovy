package com.radware.vdirect.ps.exceptions

class AuthenticationException extends RuntimeException {
    public AuthenticationException(String message) {
        super(message)
    }
}
