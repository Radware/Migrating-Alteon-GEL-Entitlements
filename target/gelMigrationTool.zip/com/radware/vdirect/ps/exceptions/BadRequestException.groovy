package com.radware.vdirect.ps.exceptions
class BadRequestException extends RuntimeException {
    BadRequestException(String msg) {
        super(msg)
    }
}
