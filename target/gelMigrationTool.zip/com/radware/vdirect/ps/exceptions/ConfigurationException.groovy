package com.radware.vdirect.ps.exceptions

class ConfigurationException extends RuntimeException {
    ConfigurationException(String msg) {
        super(msg)
    }
}
